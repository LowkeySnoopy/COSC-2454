// Lanard Johnson
//Advanced Data Structures COSC-2454
//Dr.Zaki
// 3/5/2025
// Observer

// Custom exception class for handling save errors
public class COSC2454Exception extends Exception {
    public COSC2454Exception(String message) {
        super(message); // Passes the error message to the Exception superclass
    }
}
