/* *****************************************************************************
 *  Name:    Lanard Johnson
 *   
 *  Hours to complete assignment: 27 hours
 *
 **************************************************************************** */

Programming Assignment: Java Warmup

/* *****************************************************************************
 *  Explain briefly how you implemented the Anagram Solver Problem.
 *  Which data structure did you choose (array, linked list, etc.)
 *  and why?
 **************************************************************************** */

// The Anagram Solver problem was implemented using a HashMap where the keys
// are the sorted character representations of words, and the values are lists
// of words that match the same sorted character sequence. This ensures fast
// lookup times and efficient grouping of anagrams. The sorting of characters
// was performed using Arrays.sort(), and the HashMap facilitated constant-time
// access to existing anagram groups.

/* *****************************************************************************
 *  Known bugs / limitations.
 **************************************************************************** */

// No known functional bugs, but the implementation assumes input words contain
// only lowercase alphabetic characters. If uppercase letters or special symbols
// are introduced, they would need additional preprocessing.

/* *****************************************************************************
 *  Explain briefly how you implemented the spell checker problem.
 *  Which data structure did you choose (array, linked list, etc.)
 *  and why?
 **************************************************************************** */

// The spell checker was implemented using a HashSet for storing valid words
// from the dictionary. This choice was made because HashSet provides O(1)
// average-time complexity for lookups, making it efficient for checking
// whether a given word exists in the dictionary. In addition, a Trie data
// structure was implemented for prefix-based word suggestions. The Trie
// allows for efficient searching and auto-completion, making it well-suited
// for spell-checking tasks.

/* *****************************************************************************
 *  Known bugs / limitations.
 **************************************************************************** */

// The spell checker does not handle special characters, numbers, or case
// sensitivity. The Trie structure also requires significant memory when
// dealing with large dictionaries.

/* *****************************************************************************
 *  Explain briefly how you implemented the randomized queue and deque.
 *  Which data structure did you choose (array, linked list, etc.)
 *  and why?
 **************************************************************************** */

// The randomized queue was implemented using a dynamically resizing array.
// This allows for random access and efficient element removal by swapping
// elements to the end before deletion. The resize operation follows an
// exponential growth/shrinkage pattern to optimize memory usage and avoid
// excessive reallocation.

// The deque was implemented using a doubly linked list, which supports O(1)
// insertion and deletion at both ends. This was chosen over an array because
// it avoids the need for shifting elements when adding or removing from the
// front.

/* *****************************************************************************
 *  Known bugs / limitations.
 **************************************************************************** */

// The randomized queue may suffer from performance issues if frequent resizing
// is triggered due to an inconsistent input size. The deque implementation
// currently does not support size-limited constraints.

/* *****************************************************************************
 *  Describe whatever help (if any) that you received.
 *  Don't include readings, lectures, but do
 *  include any help from people (including the professor, computing helpdesk,
 *  classmates, and friends, and generativeAI) and attribute them by name.
 **************************************************************************** */

// Received guidance from Angel on data structure selection and
// optimizing lookup times for the spell checker. Worked with Vance
// to debug edge cases related to the anagram solver.

/* *****************************************************************************
 *  Describe any serious problems you encountered.                    
 **************************************************************************** */

// Initially faced difficulties optimizing the Trie structure for fast
// prefix lookups. Also encountered performance bottlenecks when handling
// a large dataset of words in the spell checker. Debugging edge cases in
// the anagram detection process was particularly time-consuming.

/* *****************************************************************************
 *  List any other comments here. Feel free to provide any feedback   
 *  on how much you learned from doing the assignment, and whether    
 *  you enjoyed doing it.                                             
 **************************************************************************** */

// This assignment was a great exercise in understanding different data
// structures and their trade-offs. Implementing a HashMap-based anagram
// solver and a Trie-based spell checker helped solidify concepts of
// efficiency and memory management. Found the Trie implementation
// particularly interesting and useful for real-world applications.
